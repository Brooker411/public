# NFS Ansible Role Setup

This project contains reusable roles and playbooks for configuring an NFS server and mounting it on Fedora client VMs.

## Inventory
Edit `inventory.ini` to reflect your real hosts.

## Setup Instructions

### Step 1: Configure the NFS Server
```bash
ansible-playbook -i inventory.ini setup_server.yml
```

### Step 2: Configure the Clients
```bash
ansible-playbook -i inventory.ini setup_clients.yml
```

## Roles
- `nfs_server`: Formats and mounts /dev/sdb, configures `/mnt/nfs_share` as an NFS export.
- `nfs_client`: Mounts NFS share at `/mnt/nfs_client`.

## Requirements
- Fedora hosts
- NFS utilities available (`nfs-utils`)
